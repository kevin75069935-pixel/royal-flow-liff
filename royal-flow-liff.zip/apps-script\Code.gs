const SHEET_NAME = "orders";

function doGet() {
  return jsonOutput({
    status: "ok",
    service: "royal-flow-booking"
  });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData && e.postData.contents ? e.postData.contents : "{}");
    const action = body.action || "submitBooking";
    const payload = body.payload || body;

    if (action === "getRouteEstimate") {
      return jsonOutput(getRouteEstimate(payload));
    }

    if (action === "previewQuote") {
      return jsonOutput(previewQuote(payload));
    }

    if (action === "submitBooking") {
      return jsonOutput(submitBooking(payload));
    }

    return jsonOutput({
      status: "error",
      message: "未知 action：" + action
    });
  } catch (error) {
    return jsonOutput({
      status: "error",
      message: error && error.message ? error.message : String(error)
    });
  }
}

function getRouteEstimate(data) {
  const apiKey = PropertiesService.getScriptProperties().getProperty("GOOGLE_MAPS_API_KEY");
  if (!apiKey) {
    return {
      status: "error",
      message: "Apps Script 尚未設定 GOOGLE_MAPS_API_KEY，無法呼叫 Google Routes API。"
    };
  }

  if (!data.pickup || !data.dropoff) {
    return {
      status: "error",
      message: "缺少上車地點或下車地點。"
    };
  }

  const response = UrlFetchApp.fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
    method: "post",
    contentType: "application/json",
    headers: {
      "X-Goog-Api-Key": apiKey,
      "X-Goog-FieldMask": "routes.distanceMeters,routes.duration"
    },
    payload: JSON.stringify({
      origin: {
        address: data.pickup
      },
      destination: {
        address: data.dropoff
      },
      travelMode: "DRIVE",
      routingPreference: "TRAFFIC_AWARE"
    }),
    muteHttpExceptions: true
  });

  const code = response.getResponseCode();
  const text = response.getContentText();
  const result = JSON.parse(text || "{}");

  if (code < 200 || code >= 300 || !result.routes || !result.routes.length) {
    return {
      status: "error",
      message: "Google Routes 估算失敗：" + text.substring(0, 200)
    };
  }

  const route = result.routes[0];
  const distanceKm = Math.round((Number(route.distanceMeters || 0) / 1000) * 10) / 10;
  const durationMin = Math.round(parseDurationSeconds(route.duration) / 60);

  return {
    status: "success",
    distanceKm,
    durationMin
  };
}

function previewQuote(data) {
  const quote = calculateQuote(data);
  return {
    status: "success",
    quote
  };
}

function submitBooking(data) {
  const quote = calculateQuote(data);
  const orderId = data.orderId || makeOrderId();
  const sheet = getOrdersSheet();
  const now = new Date();

  sheet.appendRow([
    orderId,
    now,
    value(data.name),
    value(data.phone),
    value(data.line_user_id || data.lineUserId),
    value(data.line_display_name || data.lineDisplayName),
    value(data.service),
    value(data.date),
    value(data.time),
    value(data.pickup),
    value(data.dropoff),
    value(data.pickupAirport),
    value(data.dropoffAirport),
    value(data.terminal),
    value(data.flight),
    value(data.carType),
    value(data.passengers),
    value(data.luggage),
    value(data.childSeat),
    value(data.signService),
    value(data.englishDriver),
    value(data.stopCount),
    value(data.multiStopNote),
    value(data.tourMode),
    value(data.tourArea),
    value(data.packageRoute),
    value(data.tripDays),
    value(data.driverHotelType),
    quote.distanceKm,
    quote.durationMin,
    quote.finalPrice,
    quote.depositAmount,
    quote.balanceAmount,
    value(data.note),
    "pending"
  ]);

  return {
    status: "success",
    orderId,
    finalPrice: quote.finalPrice,
    depositAmount: quote.depositAmount,
    balanceAmount: quote.balanceAmount
  };
}

function calculateQuote(data) {
  const carType = data.carType || "標準商務車";
  const distanceKm = Number(data.distanceKm || 0);
  const durationMin = Number(data.durationMin || 0);
  const tripDays = Math.max(1, Number(data.tripDays || 1));

  let base = 1800;
  if (carType.indexOf("豪華") >= 0 || carType.indexOf("賓士") >= 0) {
    base = 2800;
  } else if (carType.indexOf("九人") >= 0 || carType.indexOf("廂型") >= 0) {
    base = 2400;
  }

  let finalPrice = base;
  if (distanceKm > 0) {
    finalPrice += Math.round(distanceKm * 45);
  }
  if (durationMin > 0) {
    finalPrice += Math.round(durationMin * 8);
  }
  if (data.service === "旅遊包車") {
    finalPrice = Math.max(finalPrice, 5500 * tripDays);
  }
  if (data.englishDriver === "需要") {
    finalPrice += 800;
  }
  if (data.signService === "需要") {
    finalPrice += 500;
  }
  if (Number(data.stopCount || 1) > 1) {
    finalPrice += (Number(data.stopCount) - 1) * 300;
  }

  finalPrice = roundToHundred(finalPrice);
  const depositAmount = roundToHundred(Math.max(1000, finalPrice * 0.3));
  const balanceAmount = Math.max(0, finalPrice - depositAmount);

  return {
    carType,
    distanceKm: distanceKm || "",
    durationMin: durationMin || "",
    surchargeNotes: buildSurchargeNotes(data),
    finalPrice,
    depositAmount,
    balanceAmount
  };
}

function getOrdersSheet() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getSheetByName(SHEET_NAME) || spreadsheet.insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "order_id",
      "created_at",
      "name",
      "phone",
      "line_user_id",
      "line_display_name",
      "service",
      "date",
      "time",
      "pickup",
      "dropoff",
      "pickup_airport",
      "dropoff_airport",
      "terminal",
      "flight",
      "car_type",
      "passengers",
      "luggage",
      "child_seat",
      "sign_service",
      "english_driver",
      "stop_count",
      "multi_stop_note",
      "tour_mode",
      "tour_area",
      "package_route",
      "trip_days",
      "driver_hotel_type",
      "distance_km",
      "duration_min",
      "final_price",
      "deposit_amount",
      "balance_amount",
      "note",
      "payment_status"
    ]);
  }

  return sheet;
}

function buildSurchargeNotes(data) {
  const notes = [];
  if (data.englishDriver === "需要") {
    notes.push("英文司機");
  }
  if (data.signService === "需要") {
    notes.push("舉牌服務");
  }
  if (Number(data.stopCount || 1) > 1) {
    notes.push("多點停靠");
  }
  if (data.service === "旅遊包車" && Number(data.tripDays || 1) > 1) {
    notes.push("多日旅遊");
  }
  return notes.length ? notes.join("、") : "無";
}

function parseDurationSeconds(duration) {
  if (!duration) {
    return 0;
  }
  return Number(String(duration).replace("s", "")) || 0;
}

function makeOrderId() {
  return "RF" + Utilities.formatDate(new Date(), "Asia/Taipei", "yyyyMMddHHmmss") + Math.floor(Math.random() * 900 + 100);
}

function roundToHundred(amount) {
  return Math.round(Number(amount || 0) / 100) * 100;
}

function value(input) {
  return input === null || input === undefined ? "" : input;
}

function jsonOutput(body) {
  return ContentService
    .createTextOutput(JSON.stringify(body))
    .setMimeType(ContentService.MimeType.JSON);
}
